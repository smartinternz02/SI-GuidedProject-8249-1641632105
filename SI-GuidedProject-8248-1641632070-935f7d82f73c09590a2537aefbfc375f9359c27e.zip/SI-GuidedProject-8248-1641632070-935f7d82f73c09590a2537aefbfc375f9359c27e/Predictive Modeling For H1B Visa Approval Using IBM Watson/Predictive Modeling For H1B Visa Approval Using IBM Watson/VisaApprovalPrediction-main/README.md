# VisaApprovalPrediction
Dataset link- //www.kaggle.com/nsharan/h-1b-visa
